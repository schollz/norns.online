package auth

import (
	"bytes"
	"fmt"
	"os/exec"
)

func GenerateKeypair(fname string) (privatekey string, publickey string, err error) {
	privatekey = fname + ".priv"
	publickey = fname + ".pub"
	cmd := exec.Command("openssl", "genrsa", "-out", privatekey, "2048")
	err = cmd.Run()
	cmd = exec.Command("openssl", "rsa", "-in", privatekey, "-out", publickey, "-pubout")
	err = cmd.Run()
	return
}

func SignFile(privatekey, fname, signaturefile string) (err error) {
	cmd := exec.Command("openssl", "dgst", "-sign", privatekey, "-out", signaturefile, fname)
	err = cmd.Run()
	return
}

func VerifyFile(publickey, fname, signaturefile string) (err error) {
	cmd := exec.Command("openssl", "dgst", "-verify", publickey, "-signature", signaturefile, fname)
	output, err := cmd.CombinedOutput()
	if err != nil {
		return
	}
	if !bytes.Contains(output, []byte("OK")) {
		err = fmt.Errorf(string(output))
	}
	return
}
